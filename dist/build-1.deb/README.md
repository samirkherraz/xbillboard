# xbillboard
Transform debian based os on raspberry pi into a billboard with 2x2 screen
